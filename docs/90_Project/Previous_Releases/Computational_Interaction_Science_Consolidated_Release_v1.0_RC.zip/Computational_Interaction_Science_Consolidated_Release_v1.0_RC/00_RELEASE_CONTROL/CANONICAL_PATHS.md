# Canonical Paths

| Concern | Canonical location | Supersedes |
|---|---|---|
| Ontology | `01_NORMATIVE_CORPUS/01_Knowledge_System_of_Record/01_Ontology/Current` | archived ontology drafts and extracted ontology copies |
| Glossary | `01_NORMATIVE_CORPUS/01_Knowledge_System_of_Record/02_Glossary` | glossary copies elsewhere |
| Contracts | `01_NORMATIVE_CORPUS/01_Knowledge_System_of_Record/05_Specifications/Contracts` | templates and paper-local restatements |
| Program synthesis | `01_NORMATIVE_CORPUS/02_Research_Papers/16_Program_Synthesis` | summaries in reports or README files |
| Canonical indexes | `02_CANONICAL_REGISTRY/03_Indexes` | earlier standalone indexes |
| Study methods | `03_PUBLICATION_INFRASTRUCTURE/03_Handbooks` | method summaries in reports |
| Publication guidance | `03_PUBLICATION_INFRASTRUCTURE/07_Guides` | earlier author/publication guides |
| Bibliography | `04_VERIFIED_BIBLIOGRAPHY/01_Master_Bibliography` | all earlier `.bib`, CSL, and formatted reference exports |
| Bibliographic audits | `04_VERIFIED_BIBLIOGRAPHY/02_Audits` | earlier metadata and duplicate reports |
| Future research | `05_VERSION_2_RESEARCH_PROGRAM` | informal roadmap notes |
