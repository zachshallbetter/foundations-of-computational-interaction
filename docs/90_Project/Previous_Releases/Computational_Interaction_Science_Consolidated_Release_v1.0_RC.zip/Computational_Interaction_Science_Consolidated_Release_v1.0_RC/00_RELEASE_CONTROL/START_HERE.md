# Start Here

For the theory and definitions, begin with:

- `01_NORMATIVE_CORPUS/01_Knowledge_System_of_Record/README.md`
- `01_NORMATIVE_CORPUS/02_Research_Papers/16_Program_Synthesis/Computational_Interaction_Science_Foundations.pdf`

For canonical term lookup and dependency inspection, use:

- `02_CANONICAL_REGISTRY/03_Indexes/Canonical_Definition_Index.csv`
- `02_CANONICAL_REGISTRY/03_Indexes/Canonical_Vocabulary.csv`
- `02_CANONICAL_REGISTRY/02_Graphs/Knowledge_Graph_Nodes.csv`
- `02_CANONICAL_REGISTRY/02_Graphs/Knowledge_Graph_Edges.csv`

For publication and study infrastructure, use:

- `03_PUBLICATION_INFRASTRUCTURE/07_Guides/Author_Guide.md`
- `03_PUBLICATION_INFRASTRUCTURE/03_Handbooks/Experimental_Handbook.md`
- `03_PUBLICATION_INFRASTRUCTURE/03_Handbooks/Measurement_Handbook.md`
- `03_PUBLICATION_INFRASTRUCTURE/04_Templates/Preregistration_Template.md`

For references, use only:

- `04_VERIFIED_BIBLIOGRAPHY/01_Master_Bibliography/Master_Bibliography_Verified.bib`
- `04_VERIFIED_BIBLIOGRAPHY/01_Master_Bibliography/Master_Bibliography_Verified.csl.json`

For unresolved scientific work, use:

- `05_VERSION_2_RESEARCH_PROGRAM/Version_2_Research_Program.md`
- `05_VERSION_2_RESEARCH_PROGRAM/Validation_Matrix.csv`
