# Computational Interaction Science — Consolidated Release Candidate

This package consolidates the Version 1.0 corpus, canonical integration artifacts, publication infrastructure, verified bibliography, and the proposed Version 2.0 validation program.

## Authority order

1. `01_NORMATIVE_CORPUS/01_Knowledge_System_of_Record` — normative definitions, ontology, contracts, and formal semantics.
2. `02_CANONICAL_REGISTRY` — indexes and machine-readable integration aids. It does not replace the Knowledge System of Record.
3. `01_NORMATIVE_CORPUS/02_Research_Papers` — evidence, argument, and provenance; these papers do not redefine canonical concepts.
4. `04_VERIFIED_BIBLIOGRAPHY` — authoritative bibliography layer for this package; it supersedes earlier bibliography exports.
5. `03_PUBLICATION_INFRASTRUCTURE` — editorial, reporting, figure, template, and maintenance infrastructure.
6. `05_VERSION_2_RESEARCH_PROGRAM` — non-normative future research; no Version 2.0 proposal is incorporated into Version 1.0 theory.

## Overlap policy

Earlier standalone packages frequently contained duplicate PDF, DOCX, Markdown, bibliography, and report exports. This consolidated release keeps each artifact in the layer that owns it and omits superseded standalone packages. File-level provenance and decisions are recorded in `90_PROVENANCE`.

## Release status

Version 1.0 remains a release candidate and a conceptual synthesis. The Version 2.0 research program is an empirical validation agenda, not a revision applied to this release.
