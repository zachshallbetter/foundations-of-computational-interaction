# Computational Interaction Science Canonical Corpus v1.0.0-integration.1

This package reconciles the uploaded Version 1.0.0 archive without introducing new theory.

## Systems of record

- `01_Canonical_System_of_Record/Canonical_Ontology.*`
- `01_Canonical_System_of_Record/Canonical_Glossary.*`
- `03_Indexes/Canonical_Vocabulary.*`
- `02_Graphs/Computational_Interaction_Knowledge_Graph.*`

## Statistics

- Concepts: 54
- Declared graph relations: 42
- Indexed research papers: 16
- Indexed source artifacts: 67

## Drift control

Source files were not changed. Candidate Version 2.0 items are isolated in the Change Report. Automated provenance assignments require human ratification before normative release.
