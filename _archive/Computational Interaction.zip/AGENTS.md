# Repository Instructions

## Examples

Every executable, interactive model, visualization, or worked scenario added to
this repository must be an identified example.

1. Allocate the next unused `CIS-EX-NNN` identifier in `examples/manifest.csv`.
2. Put the identifier and applicable theory version in the source artifact.
3. Add a complete `examples/README.md` definition covering purpose, inputs or
   controls, concepts exercised, expected behavior, non-claims, and validation.
4. Keep editable visualization fragments under `examples/visualizations/src/`
   and generated standalone files under `examples/visualizations/`.
5. Add golden assertions or behavioral tests wherever the example makes an
   executable claim.
6. Run `make test`; missing identities, missing definitions, and stale generated
   visualization output are failures.

Never reuse or renumber an example identifier. A material semantic change gets
a new identifier; a correction that restores the documented contract retains
the existing identifier and updates its validation record.
