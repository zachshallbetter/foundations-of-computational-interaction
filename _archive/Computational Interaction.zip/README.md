# Fundamental Computational Interaction Substrate

This repository turns the supplied Computational Interaction Science Version 1.0
research infrastructure into a small executable reference model. The implementation
uses C11, fixed-capacity arrays, integer arithmetic, and no third-party dependencies.
It is intentionally a substrate rather than an application framework.

## What it validates

The model keeps the research's main analytical layers separate:

- **domain commitments** are explicit state-variable, action, transition, invariant,
  participant, and role declarations;
- **system state** is a bounded vector of signed 64-bit cells;
- **operational semantics** are ordered predicates and effects;
- **projections** explicitly label preserved, transformed, introduced, and omitted
  structure and separately expose and signal actions;
- **opportunity** reports domain validity, capability, permission, enablement,
  reachability, exposure, signaling, belief, selection, execution, success, and
  reversibility as separate fields;
- **interaction** is retained as an event trace with participant identity, before and
  after state hashes, failures, and a recurrence-candidate test that makes no causal
  claim;
- **snapshots and replay** use a deterministic canonical integer encoding;
- **comparison** includes typed exact state/projection equivalence, normalized state
  similarity, and trace edit similarity under an explicit identity correspondence;
- **measurement** includes timing, frequency, completion, opportunity mismatch, and
  recovery primitives without treating any metric as a construct.

The implementation does not claim empirical construct validation. It validates that
the concepts can form a coherent, deterministic computational substrate. Strategy,
interpretation, behavioral attribution, and generalized claims remain evidence-bearing
research layers and are not inferred from raw actions.

## Build and run

```sh
make
make test
make demo
make conformance
```

These commands require only a C11 compiler and `make`. The library itself uses only
the C standard headers for fixed-width integer and size types; it performs no I/O,
allocation, filesystem, clock, network, or operating-system calls.
The library object is compiled as freestanding code, and `make test` rejects any
undefined external symbol in it. The demo and test executables use hosted C only to
print their results.

## Layout

- `include/cis.h` — complete public data model and operations
- `src/cis.c` — dependency-free implementation
- `tests/test_cis.c` — executable research-concept validation
- `tests/test_stress.c` — deterministic state-machine and opportunity stress tests
- `tests/test_examples.c` — example identity and generated-output synchronization
- `examples/README.md` — stable identifiers and complete contracts for every example
- `examples/manifest.csv` — machine-readable example identity registry
- `examples/door.c` — CIS-EX-001, smallest end-to-end interaction
- `examples/conformance.c` — CIS-EX-002, C-generated state/hash vectors
- `examples/visualizations/interaction-substrate-lab.html` — CIS-EX-003,
  self-contained experiential model
- `CONCEPT_VALIDATION.md` — disposition and validation boundary for all 54 concepts

## Deliberate limits

Capacities are compile-time constants, names are bounded byte arrays, time is an
unsigned caller-supplied tick, and values are signed 64-bit integers. Reachability is
bounded breadth-first search. Projection transforms use integer multiply/add. These
limits avoid hidden allocation and numerical behavior and make exhaustion a typed
error. Increasing a capacity changes storage only, not semantics.

Canonical concept identifiers in the supplied `Concept_Source_Matrix.csv` and
`Evidence_Register.csv` are blank. This implementation therefore uses descriptive C
identifiers and does not invent authoritative canonical IDs.
