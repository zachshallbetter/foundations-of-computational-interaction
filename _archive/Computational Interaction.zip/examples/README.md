# Identified Examples

Every example has a stable `CIS-EX-NNN` identifier. The identifier must appear
in the example source, this registry, tests that assert its contract when
applicable, and any validation document that cites it. Identifiers are never
reused. Material semantic changes require a new example identifier; corrections
that restore the documented contract retain the identifier and update its
validation history.

`manifest.csv` is the machine-readable index. Interactive examples keep an
editable HTML fragment under `visualizations/src/` and a generated standalone
HTML file under `visualizations/`; both carry the same identifier and theory
version. `make test` fails when any
registered example, description, editable source, standalone output, or source
identifier is missing.

## CIS-EX-001 — Minimal Door Transition

**Source:** `door.c`  
**Run:** `make demo`  
**Theory version:** 1.0  
**Implementation status:** executable C example

Purpose: demonstrate the smallest complete path through the public API without
introducing application architecture. The example declares one `door_open`
state cell with bounds `[0, 1]`, one `open` action, one participant, one
capability requirement, one role permission, one precondition, one effect, and
one preserved projection field. It executes at caller-supplied tick `1` and
prints projected state, trace length, and deterministic state hash.

Concepts exercised: domain commitments, system state, semantic assignment,
participant, agent, capability, permission, enablement, action, state
transition, projection, trace, token identity, and Fundamental.

Expected behavior: execution commits exactly one `0 → 1` transition, produces
one trace event, projects value `1`, and prints hash `8184434590310759885`.
Any other state, event count, result, or hash is a conformance failure.

Non-claims: the example does not establish interaction recurrence, successful
outcome, affordance, discoverability, behavior, strategy, or empirical validity.

## CIS-EX-002 — Door State Conformance Vectors

**Source:** `conformance.c`  
**Run:** `make conformance`  
**Theory version:** 1.0  
**Implementation status:** executable C reference generator

Purpose: establish a cross-representation identity check for the two-cell door
domain shared with CIS-EX-003. The example enumerates `position × locked` in
stable order and hashes each state using the production implementation. It is a
reference generator, not a second hash implementation.

Concepts exercised: system state, representation, scoped invariance, token
identity, equivalence, trace-independent snapshot identity, and Fundamental.

Expected vectors:

| Position | Locked | State hash |
|---:|---:|---:|
| 0 | 0 | 16981056525137609861 |
| 0 | 1 | 14748741118170020452 |
| 1 | 0 | 11289045597036932164 |
| 1 | 1 | 13521361004004521573 |

The vectors are golden assertions in `tests/test_cis.c` and live parity checks
in CIS-EX-003. A hash match establishes encoding parity only; it does not prove
semantic, behavioral, or interactional equivalence.

## CIS-EX-003 — Interaction Substrate Lab

**Editable source:** `visualizations/src/interaction-substrate-lab.html`  
**Standalone source:** `visualizations/interaction-substrate-lab.html`  
**Open:** load the file directly in a modern browser  
**Theory version:** 1.0  
**Implementation status:** self-contained interactive example

Purpose: make the research separations directly experienceable. The lab uses a
two-cell door domain (`position`, `locked`), four actions (`open`, `close`,
`lock`, `unlock`), and three participants whose roles and capabilities differ.
It exposes the complete opportunity profile while actions are selected,
accepted, rejected, executed, and assigned an explicit outcome.

Controls:

- participant changes role and capability conditions;
- action also declares the reachability target;
- observed outcome keeps execution separate from success;
- reachability horizon bounds breadth-first search;
- exposed, signaled, and believed switches vary independent opportunity axes;
- attempt records an accepted or rejected selection atomically;
- reset creates a fresh local episode.

Visible evidence:

- current state and projection;
- parity against all four CIS-EX-002 C vectors;
- twelve independent opportunity and trace predicates;
- belief-versus-executable-availability mismatch;
- participant-lane event trace with committed, rejected, successful, failed,
  and unknown outcomes encoded separately.

Concepts exercised: domain commitments, state, operational semantics,
participant, agent, environment, projection, capability, permission,
enablement, reachability, exposure, signaling, believed action, action,
transition, opportunity profile, trace, measurement mismatch, reversibility,
comparison parity, and Fundamental.

Expected behavior: rejected actions never mutate state; unknown outcomes never
imply success; exposure never implies signaling or belief; reachability changes
with participant authority and horizon; reversibility requires an authorized
exact forward/reverse round trip; every reachable door state matches its C hash.

Non-claims: the trace is an experiential aid, not behavioral evidence. The lab
does not infer affordance, discoverability, uptake, causal recurrence,
interaction type, policy, strategy, mechanism, or generalized validity.

Validation: browser checks cover successful and rejected transitions, explicit
outcomes, dimension independence, C-vector parity, narrow reflow, overflow, and
runtime diagnostics. The authoritative findings and boundaries are recorded in
`../CONCEPT_VALIDATION.md`.
