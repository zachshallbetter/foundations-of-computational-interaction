# Computational Interaction Science Publication Infrastructure v1.0.0

This package improves supporting research infrastructure without changing Version 1.0 theory.

## Contents
- Bibliography and audits
- Citation map, source matrix, and evidence register
- Experimental, measurement, and replication handbooks
- Reporting and contract templates
- Dataset schema and data dictionary
- Figure library and catalog
- Author and maintenance guides
- Completeness, quality, maintenance, and readiness reports

## Corpus statistics
{
  "entries": 312,
  "with_doi": 15,
  "doi_valid_format": 15,
  "with_valid_isbn": 3,
  "with_volume": 53,
  "with_issue": 53,
  "with_pages": 112,
  "duplicate_groups": 35,
  "complete_core": 312
}

## Validation boundary
Identifier format, ISBN checksum, duplicate-title, and metadata-completeness checks are automated. Publisher/Crossref authority validation is not claimed for unresolved records. No missing metadata was invented.
